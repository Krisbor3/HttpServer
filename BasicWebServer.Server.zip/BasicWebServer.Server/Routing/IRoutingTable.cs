﻿using BasicWebServer.Server.HTTP;

namespace BasicWebServer.Server.Routing
{
    public interface IRoutingTable
    {
        public IRoutingTable Map(string url, Method method, Response response);

        public IRoutingTable MapGet(string url, Response response);

        public IRoutingTable MapPost(string url, Response response);

    }
}
